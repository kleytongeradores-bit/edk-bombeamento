# EDK Elétrica - Controle de Bombeamento

Sistema de monitoramento e comando de bomba d'água (caixa + cisterna) com ESP32.

## Estrutura do projeto

```
edk-bombeamento/
├── frontend/          → Interface web (HTML) — será publicada no GitHub Pages
├── firmware/          → Código do ESP32
├── supabase/          → Scripts SQL e instruções do banco
└── docs/              → Documentação de deploy
```

## Como deixar publicado para os clientes

1. Crie um repositório no GitHub (pode ser privado).
2. Suba esta pasta inteira.
3. Ative o **GitHub Pages** apontando para a pasta `frontend` (ou raiz).
4. Configure o Supabase (veja `docs/deploy.md`).
5. Faça o upload do firmware no ESP32.
6. Envie o link do GitHub Pages para os clientes.

Os clientes acessam pelo celular ou computador pelo link público. Não precisam estar na mesma rede.

## Modos de operação

- **Local**: App fala direto com o ESP32 (mais rápido, só na mesma rede).
- **Remoto (recomendado para clientes)**: App lê/escreve no Supabase e o ESP32 sincroniza.

Veja o arquivo `docs/deploy.md` para o passo a passo completo.
