# Deploy - Deixar o app publicado para os clientes

## 1. GitHub + GitHub Pages (Frontend)

1. Crie uma conta no [GitHub](https://github.com) se ainda não tiver.
2. Crie um novo repositório (pode ser privado).
3. Faça o upload de toda a pasta `edk-bombeamento`.
4. Vá em **Settings → Pages**.
5. Em "Source" escolha a branch `main` e a pasta `/frontend`.
6. Salve. Em alguns minutos o app estará no ar em um endereço tipo:
   `https://seuusuario.github.io/edk-bombeamento/`

Esse é o link que você envia para os clientes.

## 2. Supabase (Backend remoto)

1. Crie uma conta grátis em [supabase.com](https://supabase.com).
2. Crie um novo projeto.
3. No SQL Editor, execute o conteúdo do arquivo `supabase/schema.sql`.
4. Em **Settings → API**, copie:
   - Project URL
   - `anon` public key
5. Essas duas informações vão no frontend (ou no ESP32, conforme a versão).

## 3. ESP32

- Use o firmware da pasta `firmware/`.
- Configure Wi-Fi e as credenciais do Supabase (se for usar o modo remoto).
- O ESP32 deve ter internet para sincronizar.

## 4. Segurança mínima recomendada

- Repositório GitHub **privado**.
- No Supabase, use Row Level Security (RLS) — o `schema.sql` já deixa preparado.
- Não coloque senhas de Wi-Fi nem chaves secretas no código que vai para o GitHub.
- Para clientes, o ideal é cada um ter um usuário no Supabase (Auth) ou um token próprio.

## Próximos passos sugeridos

- Adaptar o `frontend/index.html` para ler do Supabase em vez de só do IP local.
- Criar um usuário de teste no Supabase e validar o fluxo completo.
- Adicionar autenticação simples se for ter vários clientes.

Qualquer dúvida na hora de publicar, é só pedir ajuda passo a passo.
